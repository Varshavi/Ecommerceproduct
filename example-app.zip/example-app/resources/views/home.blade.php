@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-md-9">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-6"></div>
                                        <div class="col-md-6">
                                            <form action="#" method="post">
                                                @csrf
                                                <div class="form-group mb-3 float-end">
                                                    <select name="sort" id="sort" class="form-control">
                                                        <option value="">Sort By</option>
                                                        <option value="updated_date">Updated Date</option>
                                                        <option value="product_price">Price</option>
                                                        <option value="product_name">Product Name</option>
                                                    </select>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12" id="product-listing-table">
                                    {!! $products_view !!}
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <form action="#" method="post">
                                @csrf
                                <input type="hidden" name="product_id" id="productId" value="">
                                <input type="hidden" name="method" id="method" value="">
                                <div class="alert alert-success alert-dismissible save-product-details-success" style="display: none;">
                                    <button type="button" class="btn-close btn btn-sm" data-bs-dismiss="alert" aria-label="Close"></button>
                                    <p>Data saved successfully</p>
                                </div>
                                <div class="alert alert-danger alert-dismissible save-product-details-error" style="display: none;" role="alert">
                                    <button type="button" class="btn-close btn btn-sm" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                                <div class="form-group">
                                    <label for="Product Name">Product Name</label>
                                    <input type="text" name="product_name" id="productName" value="" class="form-control" />
                                    <p class="error-message mb-0" id="productNameError"></p>
                                </div>
                                <br>
                                <div class="form-group">
                                    <label for="Product Name">Product Price</label>
                                    <input type="text" name="product_price" id="productPrice" value="" class="form-control" />
                                    <p class="error-message mb-0" id="productPriceError"></p>
                                </div>
                                <br>
                                <div class="form-group">
                                    <label for="Product Description">Product Description</label>
                                    <input type="text" name="product_description" id="productDescription" value="" class="form-control" />
                                    <p class="error-message mb-0" id="productDescriptionError"></p>
                                </div>
                                <br>
                                <div class="form-group">
                                    <label for="Image">Image</label>
                                    <input type="file" name="images" id="images" class="form-control" value="" />
                                    <p class="error-message mb-0" id="images"></p>
                                </div>
                                <br>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success" id="submitproductDetailsBtn">Submit</button>
                                    <button type="button" class="btn btn-primary" id="clearFormBtn">Clear</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
