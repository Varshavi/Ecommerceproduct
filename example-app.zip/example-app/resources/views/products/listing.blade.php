<table class="table table-bordered text-center" style="width: 100%;">
    <tr>
        <th>Product Name</th>
        <th>Product Price</th>
        <th>Product Description</th>
        <th>Product Images</th>
        <th>Created At</th>
        <th>Updated At</th>
        <th>Actions</th>
    </tr>
    @forelse ($products as $product)
    <tr>
        <td>{{ $product->product_name }}</td>
        <td>{{ $product->product_price }}</td>
        <td>{{ $product->product_description }}</td>
        <td>{{ $product->images }}</td>
        <td>{{ $product->created_at }}</td>
        <td>{{ $product->updated_at }}</td>
        <td>
            <button class="btn btn-primary btn-sm editproductBtn" data-id="{{ $product->id }}" data-productname="{{ $product->product_name }}" data-producttype="{{ $product->product_type }}" data-yearofmanufacture="{{ $product->year_of_manufacture }}" data-dateofpurchase="{{ date('d-m-Y', strtotime($product->date_of_purchase)) }}" onclick="editproduct(this)">
                <i class="fas fa-edit"></i>
            </button>
            <button class="btn btn-danger btn-sm deleteproductBtn" data-id="{{ $product->id }}" onclick="deleteproduct(this)">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    </tr>
    @empty
    <tr>
        <td colspan="7">Products not found</td>
    </tr>
    @endforelse
</table>
