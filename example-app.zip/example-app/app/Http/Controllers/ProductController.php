<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    public function save_product_details(Request $request)
    {
        if ( ! $request->ajax()) {
            return redirect('/home');
        }

        $validation = Validator::make($request->all(), [
            'product_name' => ['required'],
            'product_price' => ['required'],
            'product_description' => ['required', 'min:1900', 'max:' . date('Y'), 'integer'],
            'images' => ['required']
        ]);

        if ($validation->fails()) {
            return response()->json([
                'status' => false,
                'message' => [
                    'validation_errors' => $validation->errors()
                ],
                'data' => [
                    '_token' => csrf_token()
                ]
            ]);
        }

        $product = new Product();

        if ($request->method == 'edit' && ! empty($request->id)) {
            $product = Product::find($request->id);
        }

        $product->user_id = auth()->user()->id;
        $product->product_name = $request->productName;
        $product->product_price = $request->product_price;
        $product->product_description = $request->product_description;
        $product->images = $request->image;

        $product_saved = $product->save();

        if ($product_saved) {
            return response()->json([
                'status' => true,
                'message' => 'Data inserted successfully!!!',
                'data' => [
                    'content' => $this->get_product_listing_view(),
                    '_token' => csrf_token()
                ]
            ]);
        } else {
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while storing product details',
                'data' => [
                    '_token' => csrf_token()
                ]
            ]);
        }
    }

    public function delete_product_details(Request $request)
    {
        if ( ! $request->ajax()) {
            return redirect('/home');
        }

        $validation = Validator::make($request->all(), [
            'id' => ['required', 'integer']
        ]);

        if ($validation->fails()) {
            return response()->json([
                'status' => false,
                'message' => [
                    'validation_errors' => $validation->errors()
                ],
                'data' => [
                    '_token' => csrf_token()
                ]
            ]);
        }

        $product = Product::find($request->id);

        if ($product) {
            $is_product_deleted = $product->delete();

            if ($is_product_deleted) {
                return response()->json([
                    'status' => true,
                    'message' => 'product details deleted',
                    'data' => [
                        'content' => $this->get_product_listing_view(),
                        '_token' => csrf_token()
                    ]
                    ]);
            } else {
                return response()->json([
                    'status' => false,
                    'message' => 'An error occurred while deleting record',
                    'data' => [
                        '_token' => csrf_token()
                    ]
                ]);
            }
        } else {
            return response()->json([
                'status' => false,
                'message' => 'product record not found',
                'data' => [
                    '_token' => csrf_token()
                ]
            ]);
        }
    }

    public function sort_product_details(Request $request)
    {
        if ( ! $request->ajax()) {
            return redirect('/home');
        }

        $validation = Validator::make($request->all(), [
            'attribute' => ['required', 'in:updated_date,by_descending_year,alphabetical_name']
        ]);

        if ($validation->fails()) {
            return response()->json([
                'status' => false,
                'message' => [
                    'validation_errors' => $validation->errors()
                ],
                'data' => [
                    '_token' => csrf_token()
                ]
            ]);
        }

        return response()->json([
            'status' => true,
            'message' => 'Sorted data',
            'data' => [
                'content' => $this->get_product_listing_view($request->attribute),
                '_token' => csrf_token()
            ]
        ]);
    }

    public function get_product_listing_view($order_by = null)
    {
        $products = product::where('user_id', auth()->user()->id);

        if ( ! empty($order_by)) {
            match($order_by) {
                'updated_date' => $products = $products->orderBy('updated_at', 'desc'),
                'by_descending_year' => $products = $products->orderBy('price', 'desc'),
                'alphabetical_name' => $products = $products->orderBy('product_name', 'asc')
            };
        }

        $products = $products->get();

        return view('products.listing', ['products' => $products])->render();
    }
}